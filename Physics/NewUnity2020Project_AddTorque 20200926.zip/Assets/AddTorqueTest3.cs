﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddTorqueTest3 : MonoBehaviour
{
    Rigidbody _rb;
    float magnitude = 10.0f;
    float _timer = 0.0f;
    Vector3 torque = new Vector3();

    // Start is called before the first frame update
    void Start()
    {
        _rb = GetComponent<Rigidbody>();
        torque = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            // test 03: approximate 180 degree rotation per 5 second
            float theta = Mathf.PI;
            Vector3 w = Vector3.down * theta * magnitude;
            Vector3 torque = Vector3.Scale(_rb.inertiaTensor, w);
            _rb.AddTorque(torque);
            _timer = 5.0f;

            // test 04: approximate 180 degree rotation per second
            ////Vector3 x = Vector3.Cross(oldPoint.normalized, newPoint.normalized);
            ////float theta = Mathf.Asin(x.magnitude);
            //float theta = Mathf.PI;
            //Vector3 w = Vector3.down * theta / Time.fixedDeltaTime;
            //Quaternion q = transform.rotation * _rb.inertiaTensorRotation;
            //Vector3 torque = q * Vector3.Scale(_rb.inertiaTensor, (Quaternion.Inverse(q) * w));
            //_rb.AddTorque(torque);
            //_timer = 1.0f;
        }
        _timer -= Time.deltaTime;
        if (_timer <= 0.0f)
        {
            _rb.velocity = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
        }
    }
}
