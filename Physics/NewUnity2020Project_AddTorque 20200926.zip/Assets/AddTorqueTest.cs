﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddTorqueTest : MonoBehaviour
{
    Rigidbody _rb;
    float magnitude = 10.0f;
    float _timer = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        _rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            // test 01
            Vector3 force = new Vector3(0, 0, 1) * magnitude;

            // test 02
            //Vector3 force = new Vector3(1, 0, 1) * magnitude;

            Vector3 pos = transform.position;
            pos.x += 1.0f;
            _rb.AddForceAtPosition(force, pos);
            _timer = 5.0f;
        }

        _timer -= Time.deltaTime;
        if (_timer <= 0.0f)
        {
            _rb.velocity = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
        }
    }
}
